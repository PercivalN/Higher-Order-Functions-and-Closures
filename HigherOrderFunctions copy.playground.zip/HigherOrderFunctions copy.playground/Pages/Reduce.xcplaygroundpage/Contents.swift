// REDUCE //


// 13. Reduce numbers
// Good for averages, mins, reduce a set of numbers and get one number
let heights: [Double] = [5.9, 5.11, 5.10, 6.1, 6.0, 5.1, 5.5]





//
let gitHubContributions: [Int] = [2, 12, 3, 19, 0, 0, 3, 10, 4, 6, 0, 1, 7, 11]




//
let contributions: [Int] = [2, 12, 3, 19, 0, 0, 3, 10, 4, 6, 0, 1, 7, 11]




//
let contactInfo: [String] = ["Name: Percy Ngan", "Age: 42", "Birthday: July 27th", "Email: percival.ngan@gmail.com"]






