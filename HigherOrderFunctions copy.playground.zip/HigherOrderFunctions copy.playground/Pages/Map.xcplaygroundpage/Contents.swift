// MAP //


// Transforming types
let numbers: [Int] = [0, 1, 4, 6, 12, 18, 30]



let strings: [String] = ["0", "7", "8", "17", "12"]


// Transforming elements
let heights: [Double] = [5.9, 5.11, 5.10, 6.1, 6.0, 5.1, 5.5]



// Transform into capitals
let names: [String] = ["michael", "shawn", "percy"]





 
// Challenge: use map to transform the following array from Strings into Doubles. Because everybody in the class did some extra credit, add a half grade point to each student's grade. Sort the grades from greatest to least.
let scores: [String] = ["95", "92.5", "65", "88.5", "90", "72.5", "0", "100"]


    
