// FILTER //


// Filter numbers
let scores: [Double] = [100.5, 95.5, 93.0, 90.5, 89.0, 80.0, 73.0, 65.5, 0.5]





// Filter strings
let responses: [String] = ["Yes", "no", "yes", "no", "No", "YES", "yes", "yes", "NO"]





// Challenge: use filter to divvy up the following array into two separate team lead group arrays. Each group should have an equal number of students. Jonah will take the first alphabetical half and Hayden will take the other.
let students: [String] = ["Cora", "Eoin", "Glad", "Bryson", "Sam", "Ron"]


