// SORTED //

// Sort ints
let numbers: [Int] = [1, 3, 5, 2, 4, 11, 6, 7, 9, -9, 0]




// Sort strings
let names: [String] = ["Michael", "Shawn", "Hector", "Johnny", "Sam", "Percy"]





// Challenge: Sort the following array into two separate arrays, one for ints and one for strings. Strings should be sorted alphabetically, and ints should be sorted from greatest to least.

